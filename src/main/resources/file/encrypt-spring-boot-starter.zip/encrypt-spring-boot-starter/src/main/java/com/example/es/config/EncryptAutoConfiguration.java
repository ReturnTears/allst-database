package com.example.es.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 这里ComponentScan扫描包的路径应和使用当前starter项目的包路径一致
 */
@Configuration
@ComponentScan("com.example.es")
public class EncryptAutoConfiguration {
}
