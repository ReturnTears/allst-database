create
    definer = root@localhost procedure get_all_child_nodes(IN pid int) deterministic sql security invoker
begin
    SELECT id, name FROM nodes WHERE parent_id = parent_id;
    SELECT get_all_child_nodes(id) FROM nodes WHERE parent_id = parent_id;
end;

