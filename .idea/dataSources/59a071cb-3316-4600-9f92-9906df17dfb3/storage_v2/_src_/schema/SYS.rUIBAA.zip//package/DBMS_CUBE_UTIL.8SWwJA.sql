create PACKAGE dbms_cube_util AUTHID CURRENT_USER AS

  ---------------------
  --  OVERVIEW
  --
  --  This package is the interface to cube utility functions
  --
  ---------------------
  --  Visibility
  --   All users
  --

  ---------------------
  --  CONSTANTS

  ---------------------
  --  EXCEPTIONS

  ---------------------
  --  PROCEDURES

  -- Create a report filter
  PROCEDURE create_rpt_filter(p_owner       IN VARCHAR2,
                              p_dimension   IN VARCHAR2,
                              p_rfname      IN VARCHAR2,
                              p_member_list IN VARCHAR2);

  -- Drop a report filter
  PROCEDURE drop_rpt_filter(p_owner       IN VARCHAR2,
                            p_dimension   IN VARCHAR2,
                            p_rfname      IN VARCHAR2);

  -- Drop a branch
  PROCEDURE drop_branch(p_owner       IN VARCHAR2,
                        p_dimension   IN VARCHAR2);

END dbms_cube_UTIL;
/

