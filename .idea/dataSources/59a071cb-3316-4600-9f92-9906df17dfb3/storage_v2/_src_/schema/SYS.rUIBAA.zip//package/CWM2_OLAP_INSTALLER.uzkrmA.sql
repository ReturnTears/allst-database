create package cwm2_olap_installer as

  procedure Validate_CWM2_Install;

end cwm2_olap_installer;
/

