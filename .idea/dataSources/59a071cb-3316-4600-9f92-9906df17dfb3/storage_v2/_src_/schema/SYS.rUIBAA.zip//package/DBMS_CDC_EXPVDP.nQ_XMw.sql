create PACKAGE DBMS_CDC_EXPVDP wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
165 ef
94bl95moChpJl6unSGt5eJPniEcwg43ILcsVfC+EWE6UHDXg4M2Jh+J5Nu2iv6E42bW1RMPn
Rshn5XgocmFuAJBzhedzfvDhKrxDbJHOo+gEZ1yNY6An2OOLdnzDa9O33REGMcQWhKMmc+sL
XI5wCPK3seuz7sTCwNwrh1m8tO9kpYWSH21vIyh+lW8rupwgkxbPeXNss4haDc8rpA5x5Zfa
sMf/LUa7lphVpOpFLng=
/

