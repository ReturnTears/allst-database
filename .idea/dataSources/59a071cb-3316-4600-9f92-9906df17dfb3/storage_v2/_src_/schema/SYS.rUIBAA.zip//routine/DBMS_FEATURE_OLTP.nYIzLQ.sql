create procedure DBMS_FEATURE_OLTP
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage         varchar2(1000);
    num_oltp              number;
begin
    -- initialize
    feature_boolean := 0;
    aux_count := 0;
    num_oltp := 0;


    -- check if there is something compressed
    execute immediate 'select count(*) from seg$ s ' ||
         ' where bitand(s.spare1, 2048) = 2048 AND ' ||
               ' bitand(s.spare1, 16777216) = 16777216 AND ' ||
               ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
        into num_oltp;

    if (num_oltp > 0) then
       feature_boolean := 1;
       feature_usage:='Number of OLTPCompressed Segments: '||to_char(num_oltp);
       feature_info := to_clob(feature_usage);
    else
        feature_info := to_clob('OLTP Compression not detected');
    end if;
end;
/

