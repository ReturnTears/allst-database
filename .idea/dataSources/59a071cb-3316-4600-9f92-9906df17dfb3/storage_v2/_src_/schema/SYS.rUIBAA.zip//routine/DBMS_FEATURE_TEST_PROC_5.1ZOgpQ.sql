create procedure DBMS_FEATURE_TEST_PROC_5
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
begin

    /* What happens if values are not set? */
    feature_info := 'TEST PROC 5';

end;
/

