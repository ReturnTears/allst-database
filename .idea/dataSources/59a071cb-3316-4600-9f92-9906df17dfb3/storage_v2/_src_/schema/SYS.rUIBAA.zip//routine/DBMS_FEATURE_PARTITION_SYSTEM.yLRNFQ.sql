create PROCEDURE dbms_feature_partition_system
      (is_used OUT number, data_ratio OUT number, clob_rest OUT clob)
AS
BEGIN
  -- initialize
  is_used := 0;
  data_ratio := 0;
  clob_rest := NULL;

  FOR crec IN (select num||':'||idx_or_tab||':'||ptype||':'||subptype||':'||pcnt||':'||subpcnt||':'||
                      pcols||':'||subpcols||':'||idx_flags||':'||
                      idx_type||':'||idx_uk||'|' my_string
               from (select * from
                     (select /*+ full(o) */ dense_rank() over
                             (order by  decode(i.bo#,null,p.obj#,i.bo#)) NUM,
                      decode(o.type#,1,'I',2,'T',null)  IDX_OR_TAB,
                      decode(p.parttype, 1, 'RANGE', 2, 'HASH', 3, 'SYSTEM', 4, 'LIST',
                                            'UNKNOWN') PTYPE,
                      decode(mod(p.spare2, 256), 0, null, 2, 'HASH', 3,'SYSTEM', 4, 'LIST',
                                                    'UNKNOWN') SUBPTYPE,
                      p.partcnt PCNT,
                      mod(trunc(p.spare2/65536), 65536) SUBPCNT,
                      p.partkeycols PCOLS,
                      mod(trunc(p.spare2/256), 256) SUBPCOLS,
                      decode(p.flags,0,null,decode(mod(p.flags,3),0,'LP',1,'L',2,'GP'
                                            ,null)) IDX_FLAGS,
                      decode(i.type#, 1, 'NORMAL'||
                                     decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                      9, 'DOMAIN') IDX_TYPE,
                      decode(i.property, null,null,
                                         decode(bitand(i.property, 1), 0, 'NONUNIQUE',
                                         1, 'UNIQUE', 'UNDEFINED')) IDX_UK
                      from partobj$ p, obj$ o, ind$ i
                      where o.obj# = i.obj#(+)
                      and   p.obj# = o.obj#
                      -- fix bug 3074607 - filter on obj$
                      and o.type# in (1,2,19,20,25,34,35)
                      -- exclude change tables
                      and o.obj# not in ( select obj# from cdc_change_tables$)
                      -- exclude local partitioned indexes on change tables
                      and i.bo# not in  ( select obj# from cdc_change_tables$)
                union all
                -- global nonpartitioned indexes on partitioned tables
                select dense_rank() over (order by  decode(i.bo#,null,p.obj#,i.bo#)) NUM,
                       'I' IDX_OR_TAB,
                              null,null,null,null,cols PCOLS,null,
                       'GNP' IDX_FLAGS,
                       decode(i.type#, 1, 'NORMAL'||
                                      decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                                      9, 'DOMAIN') IDX_TYPE,
                       decode(i.property, null,null,
                                          decode(bitand(i.property, 1), 0, 'NONUNIQUE',
                                          1, 'UNIQUE', 'UNDEFINED')) IDX_UK
                from partobj$ p, obj$ o, ind$ i
                where p.obj# = i.bo#
                -- exclude global nonpartitioned indexes on change tables
                and   i.bo# not in  ( select obj# from cdc_change_tables$)
                and   p.obj# = o.obj#
                and   p.flags =0
                and   bitand(i.property, 2) <>2)
                order by num, idx_or_tab desc )) LOOP

     if (is_used = 0) then
       is_used:=1;
     end if;

     clob_rest := clob_rest||crec.my_string;
   end loop;

   if (is_used = 1) then
     select pcnt into data_ratio
     from
     (
       SELECT c1, TRUNC((ratio_to_report(sum_blocks) over())*100,2) pcnt
       FROM
       (
        select decode(p.obj#,null,'REST','PARTTAB') c1, sum(s.blocks) sum_blocks
        from tabpart$ p, seg$ s
        where s.file#=p.file#(+)
        and s.block#=p.block#(+)
        and s.type#=5
        group by  decode(p.obj#,null,'REST','PARTTAB')
        )
      )
      where c1 = 'PARTTAB';
   end if;
end;
/

