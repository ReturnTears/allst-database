create FUNCTION blastn_compress (
  seqdb_cursor             blast_cur.seqdbcur_t
)
RETURN dmbcos AUTHID CURRENT_USER
  PARALLEL_ENABLE(PARTITION seqdb_cursor BY ANY)
  PIPELINED USING dmbcnimp;
/

