create PROCEDURE dbms_feature_utilities4
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   feature_usage      VARCHAR2(1000);
   feature_count      NUMBER;
   compression_count  NUMBER;
   encryption_count   NUMBER;
BEGIN
  -- initialize
  feature_info      := NULL;
  feature_usage     := NULL;
  feature_count     := 0;
  compression_count := 0;
  encryption_count  := 0;

  select usecnt, encryptcnt, compresscnt
    into feature_count, encryption_count, compression_count
    from sys.ku_utluse
   where utlname = 'Oracle Utility External Table'
     and   (last_used >=
            (SELECT nvl(max(last_sample_date), sysdate-7)
               FROM dba_feature_usage_statistics));

  feature_usage := feature_usage || 'Oracle Utility External Table ' ||
                   'invoked: ' || feature_count ||
                   ' times, compression used: ' || compression_count   ||
                   ' times, encryption used: ' || encryption_count || ' times';

  feature_info := to_clob(feature_usage);

  feature_boolean := feature_count;
  aux_count       := feature_count;
END dbms_feature_utilities4;
/

