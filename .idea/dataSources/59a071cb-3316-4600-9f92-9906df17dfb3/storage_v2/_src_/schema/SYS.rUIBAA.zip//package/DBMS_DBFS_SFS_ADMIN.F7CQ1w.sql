create package dbms_dbfs_sfs_admin
    authid definer
as



    /*
     * Bless the current session user with sufficient _direct_
     * privileges to enable them to use various DBFS API types in their
     * internal tables.
     *
     * This procedure is not meant to be invoked directly, but is a
     * helper function available for use with the
     * "dbms_dbfs_sfs.createFilesystem" method.
     *
     *
     */

    procedure   blessUser;



    /*
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.createFilesystem).
     *
     */

    function    defaultTablespace(
        uname       in          varchar2)
            return  varchar2;



    /*
     * Helper function for looking up a store id (only for use with
     * dbms_dbfs_sfs.getStoreId).
     *
     */

    function    getStoreId(
        schema_name in      varchar2,
        tbl_name    in      varchar2)
            return  number;



    /*
     * Helper function for space usage queries (only for use with
     * dbms_dbfs_sfs.spaceUsage).
     *
     */

    procedure   spaceUsage(
        schema_name in          varchar2,
        tbl_name    in          varchar2,
        blksize     out         integer,
        tbytes      out         integer,
        fbytes      out         integer);



    /*
     * Create a POSIX store.
     *
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.createFilesystem).
     *
     *
     * Add a newly created POSIX table to the list of known POSIX
     * tables. At this stage, no store is registered to a particular
     * owner as an accessible filesystem (use "registerFilesystem", if
     * needed).
     *
     * The (schema_name, tbl_name) and its identifier (tabid) must both
     * be database-wide unique. If the table uses object-types,
     * "ptbl_name" should be "null", else the name of a valid properties
     * table.
     *
     */

    procedure   createFilesystem(
        tabid       in              number,
        schema_name in              varchar2,
        tbl_name    in              varchar2,
        ptbl_name   in              varchar2,
        version     in              varchar2,
        properties  in              dbms_dbfs_content_properties_t
                                                default null);



    /*
     * Register a POSIX store.
     *
     *
     * Register an already created POSIX store table
     * (dbms_dbfs_sfs.createFilesystem) in schema "schema_name", table
     * "tbl_name", as a new filesystem named "store_name".
     *
     * The new filesystem/store can optionally be volume/snapshot
     * qualified (by default the "main" volume and current snapshot are
     * used).
     *
     * The same table can be registered as different filesystems by the
     * same/different user as long as the "store_name" and (schema_name,
     * tbl_name, volume_name, snapshot_name) tuple are unique per-user.
     *
     */

    procedure   registerFilesystem(
        store_name      in          varchar2,
        schema_name     in          varchar2,
        tbl_name        in          varchar2,
        volume_name     in          varchar2    default 'main',
        snapshot_name   in          varchar2    default null);



    /*
     * Unregister a POSIX store.
     *
     *
     * The store is removed from the metadata tables, unregistered from
     * the DBFS API, but the underlying filesystem itself is otherwise
     * untouched.
     *
     */

    procedure   unregisterFilesystem(
        store       in              varchar2);



    /*
     * Initialize a POSIX store.
     *
     * Helper function for store initialization (only for use with
     * dbms_dbfs_sfs.initFS).
     *
     *
     * Remove all volumes and snapshots associated with a POSIX
     * filesystem table, and update its "formatted" timestamp.
     *
     */

    procedure   initFilesystem(
        schema_name in              varchar2,
        tbl_name    in              varchar2);



    /*
     * Drop a POSIX store.
     *
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.dropFilesystem).
     *
     *
     * Remove a POSIX filesystem table from the list of known POSIX
     * filesystem tables.
     *
     * The table underlying the store must not be in use (i.e. all
     * filesystems referring to this table must have been unregistered
     * prior to this call).
     *
     */

    procedure   dropFilesystem(
        schema_name in              varchar2,
        tbl_name    in              varchar2);



    /*
     * Snapshot operations.
     *
     * Helper functions for snapshot operations meant to be invoked only
     * from "dbms_dbfs_sfs".
     *
     */

    procedure   createSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');

    procedure   revertSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');

    procedure   dropSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');



    /*
     * Drop _all_ POSIX filesystem tables.
     *
     * Action to be invoked only during cleanup/downgrade.
     *
     */

    procedure   drop_all_tables;
end;
/

