create PACKAGE dbms_aw_xml AUTHID CURRENT_USER AS

  FUNCTION execute(input IN CLOB) RETURN VARCHAR2;
  FUNCTION readAWMetadata(input varchar2, input2 varchar2)
             RETURN GENWSTRINGSEQUENCE;
  PROCEDURE readAWMetadata1(byteParams IN OUT GENRAWSEQUENCE, wstrParams IN OUT GENWSTRINGSEQUENCE);
  FUNCTION executefile(dirname IN VARCHAR2, fname IN VARCHAR2) RETURN VARCHAR2;

END dbms_aw_xml;
/

