create package dbms_flashback_archive AUTHID CURRENT_USER as

-- FDA Disassociation
procedure disassociate_fba(owner_name VARCHAR2, table_name VARCHAR2);
procedure reassociate_fba(owner_name VARCHAR2, table_name VARCHAR2);

end;
/

