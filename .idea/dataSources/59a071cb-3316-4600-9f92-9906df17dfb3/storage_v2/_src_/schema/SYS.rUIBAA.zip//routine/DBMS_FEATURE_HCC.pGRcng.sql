create procedure DBMS_FEATURE_HCC
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage         varchar2(1000);
    num_cmp_dollar        number;
    num_level1            number;
    num_level2            number;
    num_level3            number;
    num_level4            number;
    num_hcc               number;
    blk_level1           number;
    blk_level2           number;
    blk_level3           number;
    blk_level4           number;
begin
    -- initialize
    feature_boolean := 0;
    aux_count := 0;
    num_cmp_dollar := 0;
    num_hcc := 0;
    num_level1  := 0;
    num_level2  := 0;
    num_level3  := 0;
    num_level4 := 0;
    blk_level1 := 0;
    blk_level2 := 0;
    blk_level3 := 0;
    blk_level4 := 0;

    -- check for HCC usage from compression dict table
    execute immediate 'select count(*) from compression$ '
        into num_cmp_dollar;

    -- check if there is something compressed
    execute immediate 'select count(*) from seg$ s ' ||
         ' where (bitand(s.spare1, 234881024) = 33554432 OR ' ||
               ' bitand(s.spare1, 234881024) = 67108864 OR ' ||
               ' bitand(s.spare1, 234881024) = 100663296 OR ' ||
               ' bitand(s.spare1, 234881024) = 134217728) AND ' ||
               ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
        into num_hcc;

    if ((num_cmp_dollar > 0) OR (num_hcc > 0)) then

        feature_boolean := 1;

        -- check for HCC for Query LOW (level 1)
        execute immediate 'select count(*) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 33554432 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into num_level1;

        execute immediate 'select sum(blocks) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 33554432 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into blk_level1;

        -- check for HCC for Query HIGH (level 2)
        execute immediate 'select count(*) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 67108864 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into num_level2;

        execute immediate 'select sum(blocks) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 67108864 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into blk_level2;

        -- check for HCC for Archive Low(level 3)
        execute immediate 'select count(*) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 100663296 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into num_level3;

        execute immediate 'select sum(blocks) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 100663296 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into blk_level3;

        -- check for HCC for Archive High(level 4)
        execute immediate 'select count(*) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 134217728 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into num_level4;

        execute immediate 'select sum(blocks) from seg$ s ' ||
          ' where bitand(s.spare1, 2048) = 2048 AND ' ||
                ' bitand(s.spare1, 234881024) = 134217728 AND ' ||
                ' IS_INTERNAL_SEGMENT(s.file#, s.block#, s.ts#) = 0 '
           into blk_level4;


     feature_usage :=
      'Number of Hybrid Columnar Compressed Segments: ' || to_char(num_hcc) ||
        ', ' || ' Segments Analyzed: ' || to_char(num_cmp_dollar) ||
        ', ' || ' Segments Compressed Query Low: ' || to_char(num_level1) ||
        ', ' || ' Blocks Compressed Query Low: ' || to_char(blk_level1) ||
        ', ' || ' Segments Compressed Query High: ' || to_char(num_level2) ||
        ', ' || ' Blocks Compressed Query High: ' || to_char(blk_level2) ||
        ', ' || ' Segments Compressed Archive Low: ' || to_char(num_level3) ||
        ', ' || ' Blocks Compressed Archive Low: ' || to_char(blk_level3) ||
        ', ' || ' Segments Compressed Archive High: ' || to_char(num_level4) ||
        ', ' || ' Blocks Compressed Archive High: ' || to_char(blk_level4);

        feature_info := to_clob(feature_usage);
    else
        feature_info := to_clob('Hybrid Columnar Compression not detected');
    end if;

end;
/

