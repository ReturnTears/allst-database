create PROCEDURE dbms_feature_job_scheduler
      (is_used OUT number, nr_of_jobs OUT number, summary OUT clob)
AS
  nr_classes Number;
  nr_windows Number;
  nr_schedules Number;
  nr_programs Number;
  nr_credentials Number;

BEGIN
  select count(*) into nr_of_jobs from dba_scheduler_jobs where
      owner not in ('SYS', 'ORACLE_OCM', 'EXFSYS' )
       and job_name not like 'AQ$%'
       and job_name not like 'MV_RF$J_%';

  is_used := nr_of_jobs;
  -- if job used
  if is_used = 0  then return; end if;


   for item in (
select   job_type,
         job_style,
         schedule_type,
         cred,
         dest,
         count(*) nr_jobs
from
(
select job_type, job_style, schedule_type,
           decode(credential_name,null, 'NO_CREDENTIAL', 'CREDENTIAL') cred,
           decode(destination,null, 'NO_DESTINATION', 'DESTINATION') dest
from  dba_scheduler_jobs
          where
                owner not in ('SYS', 'ORACLE_OCM', 'EXFSYS' )
            and job_name not like 'AQ$%'
            and job_name not like 'MV_RF$J_%'
            and job_type  is not null
            and schedule_type != 'NAMED'
union all
select program_type, job_style, schedule_type,
           decode(credential_name,null, 'NO_CREDENTIAL', 'CREDENTIAL'),
           decode(destination,null, 'NO_DESTINATION', 'DESTINATION')
from dba_scheduler_jobs j,
         dba_scheduler_programs p
    where
                j.owner not in ('SYS', 'ORACLE_OCM', 'EXFSYS' )
            and job_name not like 'AQ$%'
            and job_name not like 'MV_RF$J_%'
            and job_type is null
            and p.owner = j.program_owner
            and p.program_name = j.program_name
            and schedule_type != 'NAMED'
union all
select job_type, job_style, s.schedule_type ,
           decode(credential_name,null, 'NO_CREDENTIAL', 'CREDENTIAL'),
           decode(destination,null, 'NO_DESTINATION', 'DESTINATION')
from  dba_scheduler_jobs  j,  dba_scheduler_schedules s
          where
                j.owner not in ('SYS', 'ORACLE_OCM', 'EXFSYS' )
            and job_name not like 'AQ$%'
            and job_name not like 'MV_RF$J_%'
            and job_type  is not null
            and j.schedule_type = 'NAMED'
            and  s.owner = j.schedule_owner
            and  s.schedule_name = j.schedule_name
union all
select program_type, job_style, s.schedule_type ,
           decode(credential_name,null, 'NO_CREDENTIAL', 'CREDENTIAL'),
           decode(destination,null, 'NO_DESTINATION', 'DESTINATION')
from  dba_scheduler_jobs  j,  dba_scheduler_schedules s,
                  dba_scheduler_programs p
          where
                j.owner not in ('SYS', 'ORACLE_OCM', 'EXFSYS' )
            and job_name not like 'AQ$%'
            and job_name not like 'MV_RF$J_%'
            and job_type  is null
            and j.schedule_type = 'NAMED'
            and s.owner = j.schedule_owner
            and s.schedule_name = j.schedule_name
            and p.owner = j.program_owner
            and p.program_name = j.program_name
)
group by cube  (  job_type,  job_style, schedule_type, cred, dest)
          having grouping(job_type)
                      + grouping(job_style)
                      + grouping(schedule_type)
                      + grouping(cred)
                      + grouping(dest) = 4

)
       loop
        summary  := summary || ':' || item.job_type || item.job_style
                      || item.schedule_type || item.cred
                      || item.dest || '_JOBS:' || item.nr_jobs;
       end loop;

       select count(*) into nr_classes from dba_scheduler_job_classes;
       select count(*) into nr_windows from dba_scheduler_windows;
       select count(*) into nr_programs from dba_scheduler_programs;
       select count(*) into nr_schedules from dba_scheduler_schedules;
       select count(*) into nr_credentials from dba_scheduler_credentials;
      summary := summary ||  ':NR_CLASSES:' || nr_classes
                         ||  ':NR_WINDOWS:' || nr_windows
                         ||  ':NR_PROGRAMS:' || nr_programs
                         ||  ':NR_SCHEDULES:' || nr_schedules
                         ||  ':NR_CREDENTIALS:' || nr_credentials;
END;
/

