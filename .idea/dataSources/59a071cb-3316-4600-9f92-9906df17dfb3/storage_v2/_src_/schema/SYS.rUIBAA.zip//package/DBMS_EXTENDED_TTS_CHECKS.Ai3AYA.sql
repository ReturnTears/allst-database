create PACKAGE     DBMS_EXTENDED_TTS_CHECKS IS

  /*************************************************************************
      Data Structures
   *************************************************************************/

  -- following data structure is used to pass information about an object
  TYPE objrec IS RECORD (
        v_pobjschema    varchar2(30),
        v_pobjname      varchar2(30),
        v_objid         number,
        v_objname       varchar2(30),
        v_objsubname    varchar2(30),
        v_objowner      varchar2(30),
        v_objtype       varchar2(15));

  --  List of object records
  TYPE t_objlist IS TABLE OF objrec
    INDEX BY BINARY_INTEGER;

  --++
  -- Definition:  This function verifies Schema based XMLType tables that are
  --              part of the transport set are self contained. i.e. the out of
  --              line pieces that the table points to are also part of the
  --              transport set. This will ensure that the SB XMLType table is
  --              self contained.
  --
  -- Inputs:      tsnames - plsql table of tablespace names
  --              fromexp - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  Function  verify_XMLSchema(
        tsnames dbms_tts.tablespace_names,
        fromExp in boolean)
    RETURN boolean;

  --++
  -- Function      check_csx_closure
  --
  -- Description:  Verifies that all token manager tables for XML tables and columns
  --               with binary storage (CSX) are also contained in the transported
  --               tablespaces. This is needed so that data at the import site can be
  --               decoded without a full remapping.
  --
  --               To be combined with verify_XMLSchema.
  --
  -- Inputs:       tsnames  - comma separated list of tablespace names
  --               fromExp  - being called by export?
  --
  -- Outputs:      None
  --
  -- Results       True if contained, otherwise false.
  --               As for verify_XMLSchema, even if violation is found, returns true
  --               if from Exp is false.
  --++
  FUNCTION check_csx_closure(
      tsnames IN dbms_tts.tablespace_names,
      fromExp IN  boolean )
    RETURN boolean;

  --++

  --++
  -- Definition:  This function verifies secondary objects that are associated
  --              with an extensible index are contained in the list of
  --              tablespaces or fully outside the list. This guarantees self
  --              containment of all or none of the secondary objects
  --              associated with the extensible index. For simple types like
  --              tables and indexes it is clear why this check works. What may
  --              not be so obvious is that this works even for objects like
  --              partitions, lobs etc.  For e.g. if Table T1 is partitioned
  --              two ways P1 and P2, has a lob object L1 and Table T2 is an
  --              IOT, and extensible index E1 is associated with L1 and T2
  --              then it is sufficient just check that tablespace(L1) and
  --              tablespace(T2) are either fully contained or fully out of
  --              the tts set. Self Containment of T1 and T2 is guaranteed by
  --              the straddling_rs_objects function
  --
  -- Inputs:      fromexp - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  Function  verify_Extensible (
        fromExp in boolean)
    RETURN boolean;

  --++
  -- Definition :  This function verifies that:
  --               1. Materialized view logs stored as tables and the
  --                  corresponding master tables are self contained. The
  --                  containment check is similar to tables and its indexes:
  --                  If full_check is TRUE, then BOTH the MV log and the
  --                  master table must be in or both must be out of the
  --                  transportable set. If full_check is FALSE, then it is ok
  --                  for the MV log to be out of the transportable set but it
  --                  is NOT ok for the MV log to be in and its master table to
  --                  be out of the set.
  --               2. Updateable Materialized view tables and their
  --                  corresponding logs are fully contained in the
  --                  transportable set.
  --
  --               If fromExp is false, populate the violation table with the
  --               offending violation object information for each violation.
  --
  --               Note that it is ok to transport just the MVs and not their
  --               masters or vice versa. It is also ok to just transport
  --               master tables without the mv logs, but NOT vice versa.
  --
  -- Inputs:      fromexp    - stop after first violation found
  --              full_check - perform full check - described above
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  FUNCTION verify_MV (
        fromExp         in boolean,
        full_check      in boolean)
    RETURN boolean;

  --++
  -- Definition:  This function verifies that all nested tables are fully in or
  --              out of the tts set.
  --
  -- Inputs:      fromexp    - stop after first violation found
  --
  -- Outputs:     None
  --
  -- Returns:     If fromExp is true, return false if violation found, true
  --              for all other cases (even if violations have been found).
  --++
  FUNCTION  verify_NT(
        fromExp in boolean)
    RETURN boolean;

  --++
  -- Definition:  This function ensures that the group of objects that are
  --              passed in either are fully IN or OUT of the tslist (set of
  --              tablespaces to be transported
  --
  -- Inputs:      vobjlist
  --
  -- Outputs:     None
  --
  -- Return:      straddling objects across transportable set - 0
  --              all objects in list are fully contained     - 1
  --              all objects in list are fully outside       - 2
  --++
  FUNCTION objectlist_Contained(
        vobjlist        t_objlist)
    RETURN number;

  --
  -- The following get_tablespace_* functions take information about an object
  -- that takes up physical storage in the database and returns the tablespace
  -- name associated with the object.
  --

  --++
  -- Definition:  This function checks if table is non partitioned and not an
  --              IOT then return its tablespace.  If the TABLE is an IOT or
  --              partitioned then just return the tablespace associated with
  --              the index or the first partition respectively. If a specific
  --              tablespace is needed then the get_tablespace_tabpart routine
  --              should be invoked by the caller.
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_tab(
        object_id       number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Description:  If the INDEX is partitioned then simply return the
  --               tablespace associated the first partition
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_ind(
        object_id       number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Definition:  If the table is partitioned, then return the tablespace
  --              associated with the first partition
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_tabpart(
        object_id       number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Definition:  If the index is partitioned, then return the tablespace
  --              associated with the first partition
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_indpart(
        object_id       IN number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Definition:  Return the tablespace associated with the first subpartition
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_tabsubpart(
        object_id       number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Definition:  Return the tablespace associated with the first subpartition
  --
  -- Inputs:      object_id      - obj# of object to check
  --              object_owner   - owner of object
  --              object_name    - object name
  --              object_subname - object subname (partition or subpartition)
  --              object_type    - object type
  --
  -- Outputs:     None
  --
  -- Returns:     Tablespace name
  --++
  FUNCTION get_tablespace_indsubpart(
        object_id       number,
        object_owner    varchar2,
        object_name     varchar2,
        object_subname  varchar2,
        object_type     varchar2)
    RETURN varchar2;

  --++
  -- Description:  This function returns objects associated with an extensible
  --               index in a list format
  --
  -- Inputs:       objn   - object number
  --
  -- Outputs:      None
  --
  -- Returns       objects associated with an extensible index in a list format
  FUNCTION get_domain_index_secobj(
        objn    number)
    RETURN t_objlist;

  --++
  -- Description:  This function returns child nested tables associated with a
  --               parent nested table object in a list format
  --
  -- Inputs:       objn   - object number
  --
  -- Outputs:      None
  --
  -- Returns       child nested tables associated with a parent nested table
  --               object in a list format
  FUNCTION get_child_nested_tables(
        objn    number)
    RETURN t_objlist;

END DBMS_EXTENDED_TTS_CHECKS;
/

