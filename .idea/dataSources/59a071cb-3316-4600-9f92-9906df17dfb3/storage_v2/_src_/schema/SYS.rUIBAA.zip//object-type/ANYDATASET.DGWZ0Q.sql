create TYPE     AnyDataSet         as OPAQUE VARYING (*)
USING library DBMS_ANYDATASET_LIB
(
/* CONSTRUCTION */
  /* NOTE - The AnyDataSet needs to be contructed value by value sequentially.
            For each data instance (of the type of the AnyDataSet),
            the AddInstance() function need to be invoked.
            This adds a new data instance to the AnyDataSet.
            Subsequently, Set*() can be called to set each value
            in its entirety.
            The MODE of construction/access can be changed to attribute/
            collection element wise by making calls to PieceWise()
             - If the type of the AnyDataSet is TYPECODE_OBJECT,
               individual attributes will be set with subsequent
               Set*() calls. Likewise on access.
             - If the type of the current data value is a collection type
               individual collection elements will be set with subsequent
               Set*() calls. Likewise on access.
            This call is very similar to AnyData.PieceWise() call defined for
            the type SYS.AnyData.
            NOTE - There is no support for piecewise construction and access
                   of nested (not top level) attributes that are of object
                   types or collection types.
            EndCreate should be called to finish the construction
            process (before which no access calls can be made).
  */
  /* NAME
         BeginCreate
     DESCRIPTION
         Creates a new AnyDataSet which can be used to create a Set of data
         values of the given ANYTYPE.
     PARAMETERS
         typecode - the typecode for the type of the AnyDataSet
         dtype - The Type of the data values. This parameter is a must for
                 user-defined types like TYPECODE_OBJECT, Collection typecodes
                 etc.
         aset - The AnyDataSet being constructed.
     EXCEPTIONS
         - DBMS_TYPES.invalid_parameters
           dtype is invalid (not fully constructed etc.).
  */
  STATIC PROCEDURE BeginCreate(typecode IN PLS_INTEGER,
           rtype IN OUT NOCOPY AnyType, aset OUT NOCOPY AnyDataSet),
  /* NAME
         AddInstance.
     DESCRIPTION
         Add a new data instance to a AnyDataSet.
     EXCEPTIONS
         - DBMS_TYPES.invalid_parameters
         - DBMS_TYPES.incorrect_usage
           On incorrect usage.
     NOTE
         The data instances have to be added sequentially. The previous data
         instance must be fully constructed (or set to null) before a new one
         can be added.
         This call DOES NOT automatically set the mode of construction to be
         piece-wise. The user has to explicitly call PieceWise() if a
         piece-wise construction of the instance is intended.
  */
  MEMBER PROCEDURE AddInstance(self IN OUT NOCOPY AnyDataSet),
  /* NAME
         PieceWise.
     DESCRIPTION
         This call sets the MODE of construction, access of the data value to
         be an attribute at a time (if the data value is of TYPECODE_OBJECT).
         It sets the MODE of construction, access of the data value to be a
         collection element at a time (if the data value is of
         collection TYPE). Once this call has been made, subsequent
         Set*'s and Get* will sequentially obtain
         individual attributes or collection elements.
    EXCEPTIONS
         - DBMS_TYPES.invalid_parameters
         - DBMS_TYPES.incorrect_usage
           On incorrect usage.
    NOTE
         The current data value must be of an OBJECT or COLLECTION type before
         this call can be made. There is no support for piece-wise
         construction or access of embedded object type attributes (or nested
         collections).
  */
  MEMBER PROCEDURE PieceWise(self IN OUT NOCOPY AnyDataSet),
  /* NAME
         Set*.
     DESCRIPTION
         Sets the current data value.
         The type of the current data value depends on the MODE with which
         we are constructing (Depending on how we have invoked the
         PieceWise() call).
         The type of the current data should be the type of the
         AnyDataSet if PieceWise() has NOT been called. The type
         should be the type of the attribute at the current position if
         PieceWise() has been called.
     PARAMETERS
         num - The Number that needs to be set. etc.
         last_elem - This parameter is relevant only if PieceWise()
                     has been already called (for a collection).
                     Set to TRUE if it is the last element of the collection,
                     FALSE otherwise.
     EXCEPTIONS
         - DBMS_TYPES.invalid_parameters
           Invalid Parameters (if it is not appropriate to add a number
                               at this point in the creation process).
         - DBMS_TYPES.incorrect_usage
           Incorrect usage.
         - DBMS_TYPES.type_mismatch
           When the expected type is different from the passed in type.
     NOTE
         Sets the current data value.
  */
  MEMBER PROCEDURE SetNumber(self IN OUT NOCOPY AnyDataSet,
             num IN NUMBER, last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetDate(self IN OUT NOCOPY AnyDataSet,
             dat IN DATE, last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetChar(self IN OUT NOCOPY AnyDataSet, c IN CHAR,
             last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetVarchar(self IN OUT NOCOPY AnyDataSet,
             c IN VARCHAR, last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetVarchar2(self IN OUT NOCOPY AnyDataSet,
             c IN VARCHAR2, last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetRaw(self IN OUT NOCOPY AnyDataSet, r IN RAW,
             last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetBlob(self IN OUT NOCOPY AnyDataSet, b IN BLOB,
             last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetClob(self IN OUT NOCOPY AnyDataSet, c IN CLOB,
             last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetBfile(self IN OUT NOCOPY AnyDataSet,
             b IN BFILE, last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetObject(self IN OUT NOCOPY AnyDataSet,
             obj IN "<ADT_1>", last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetObject(self IN OUT NOCOPY AnyDataSet,
             obj IN "<OPAQUE_1>", last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetRef(self IN OUT NOCOPY AnyDataSet,
             rf IN REF "<ADT_1>", last_elem boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetCollection(self IN OUT NOCOPY AnyDataSet,
             col IN "<COLLECTION_1>", last_elem boolean DEFAULT FALSE),
  /*
     NAME
          EndCreate
     DESCRIPTION
          Ends Creation of a AnyDataSet. Other creation functions cannot be
          called after this call.
  */
  MEMBER PROCEDURE EndCreate(self IN OUT NOCOPY AnyDataSet),
  /* ----------------------------------------------------------------------- */
  /* ACCESSORS */
  /* ----------------------------------------------------------------------- */
  /*
     NAME
          GetTypeName
     DESCRIPTION
          Get the fully qualified Type Name for the AnyDataSet.
          If the AnyDataSet is based on a builtin, this function will return
          NUMBER etc.
          If it is based on a user defined type, this function will return
          <schema_name>.<type_name>. e.g. SCOTT.FOO.
          If it is based on a transient anonymous type, this function will
          return NULL.
     RETURNS
          Type name of the AnyDataSet.
  */
  MEMBER FUNCTION GetTypeName(self IN AnyDataSet) return VARCHAR2
                       DETERMINISTIC,
  /* NAME
         GetType
     DESCRIPTION
         Gets the AnyType describing the type of the data instances in an
         AnyDataSet.
     PARAMETER
         typ (OUT) - The AnyType corresponding to the AnyData. May be NULL
                     if it does not represent a user-defined type.
     RETURNS
         The typecode corresponding to the type of the AnyData.
     EXCEPTIONS
  */
  MEMBER FUNCTION GetType(self IN AnyDataSet, typ OUT NOCOPY AnyType)
           return PLS_INTEGER,
  /* NAME
         GetInstance
     DESCRIPTION
         Get's the next instance in an AnyDataSet. Only sequential access to
         the instances in an AnyDataSet is allowed. After this function has
         been called, the Get*() functions can be invoked on the
         AnyDataSet to access the current instance. If PieceWise() is called
         before doing the Get*() calls, the individual attributes
         (or collection elements) can be accessed. It is an error to invoke
          this function before the AnyDataSet is fully created.
     PARAMETERS
         self (IN OUT )   - The AnyDataSet being accessed.
         return          - DBMS_TYPES.SUCCESS or DBMS_TYPES.NO_DATA.
                           DBMS_TYPES.NO_DATA signifies the end of the
                           AnyDataSet when all instances have been accessed.
     NOTE
         This function should be called even before accessing the 1st
         instance.
  */
  MEMBER FUNCTION GetInstance(self IN OUT NOCOPY AnyDataSet)
            return PLS_INTEGER,
  /* NAME
         Get*.
     DESCRIPTION
         Gets the current data value (which should be of appropriate type)
         The type of the current data value depends on the MODE with which
         we are accessing (Depending on how we have invoked the
         PieceWise() call).
         If PieceWise() has NOT been called, we are accessing the
         instance in its entirety and the type of the data value should match
         the type of the AnyDataSet.
         If PieceWise() has been called, we are accessing the
         instance piece wise. The type of the data value should match the type
         of the attribute (or collection element) at the current position.
     PARAMETERS
         num - The Number that needs to be got. etc.
     RETURNS
         DBMS_TYPES.SUCCESS or DBMS_TYPES.NO_DATA
         The return value is relevant only if PieceWise
         has been already called (for a collection). In such a case,
         DBMS_TYPES.NO_DATA signifies the end of the collection when all
         elements have been accessed.
     EXCEPTIONS
         - DBMS_TYPES.invalid_parameters
           Invalid Parameters (if it is not appropriate to add a number
                               at this point in the creation process).
         - DBMS_TYPES.incorrect_usage
           Incorrect usage.
         - DBMS_TYPES.type_mismatch
           When the expected type is different from the passed in type.
  */
  MEMBER FUNCTION GetNumber(self IN AnyDataSet, num OUT NOCOPY NUMBER)
              return PLS_INTEGER,
  MEMBER FUNCTION GetDate(self IN AnyDataSet, dat OUT NOCOPY DATE)
              return PLS_INTEGER,
  MEMBER FUNCTION GetChar(self IN AnyDataSet, c OUT NOCOPY CHAR)
              return PLS_INTEGER,
  MEMBER FUNCTION GetVarchar(self IN AnyDataSet, c OUT NOCOPY VARCHAR)
              return PLS_INTEGER,
  MEMBER FUNCTION GetVarchar2(self IN AnyDataSet, c OUT NOCOPY VARCHAR2)
              return PLS_INTEGER,
  MEMBER FUNCTION GetRaw(self IN AnyDataSet, r OUT NOCOPY RAW)
              return PLS_INTEGER,
  MEMBER FUNCTION GetBlob(self IN AnyDataSet, b OUT NOCOPY BLOB)
              return PLS_INTEGER,
  MEMBER FUNCTION GetClob(self IN AnyDataSet, c OUT NOCOPY CLOB)
              return PLS_INTEGER,
  MEMBER FUNCTION GetBfile(self IN AnyDataSet, b OUT NOCOPY BFILE)
              return PLS_INTEGER,
  MEMBER FUNCTION GetObject(self IN AnyDataSet, obj OUT NOCOPY "<ADT_1>")
              return PLS_INTEGER,
  MEMBER FUNCTION GetObject(self IN AnyDataSet, obj OUT NOCOPY "<OPAQUE_1>")
              return PLS_INTEGER,
  MEMBER FUNCTION GetRef(self IN AnyDataSet, rf OUT NOCOPY REF "<ADT_1>")
              return PLS_INTEGER,
  MEMBER FUNCTION GetCollection(self IN AnyDataSet,
              col OUT NOCOPY "<COLLECTION_1>") return PLS_INTEGER,
  /* NAME
         GetCount
     DESCRIPTION
         Gets the number of data instances in a AnyDataSet.
     PARAMETERS
     EXCEPTIONS
         None.
  */
  MEMBER FUNCTION GetCount(self IN AnyDataSet) return PLS_INTEGER,
  /***************************************************************************/
  /* NEWLY ADDED FUNCTIONS IN 9iR2 */
  /***************************************************************************/
  /* Set Functions for Datetime and NCHAR types. */
  MEMBER PROCEDURE SetTimestamp(self IN OUT NOCOPY AnyDataSet, ts IN TIMESTAMP_UNCONSTRAINED,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetTimestampTZ(self IN OUT NOCOPY AnyDataSet,
                    ts IN TIMESTAMP_TZ_UNCONSTRAINED,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetTimestampLTZ(self IN OUT NOCOPY AnyDataSet,
                    ts IN TIMESTAMP_LTZ_UNCONSTRAINED,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetIntervalYM(self IN OUT NOCOPY AnyDataSet,
                    inv IN YMINTERVAL_UNCONSTRAINED,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetIntervalDS(self IN OUT NOCOPY AnyDataSet,
                    inv IN DSINTERVAL_UNCONSTRAINED,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetNchar(self IN OUT NOCOPY AnyDataSet,
                    nc IN NCHAR, last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetNVarchar2(self IN OUT NOCOPY AnyDataSet,
                    nc IN NVarchar2, last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetNClob(self IN OUT NOCOPY AnyDataSet,
                    nc IN NClob, last_elem IN boolean DEFAULT FALSE),
  /* Get Functions for Datetime and NCHAR types. */
  MEMBER FUNCTION GetTimestamp(self IN AnyDataSet, ts OUT NOCOPY TIMESTAMP_UNCONSTRAINED)
       return PLS_INTEGER,
  MEMBER FUNCTION GetTimestampTZ(self IN AnyDataSet,
       ts OUT NOCOPY TIMESTAMP_TZ_UNCONSTRAINED) return PLS_INTEGER,
  MEMBER FUNCTION GetTimestampLTZ(self IN AnyDataSet,
       ts OUT NOCOPY TIMESTAMP_LTZ_UNCONSTRAINED) return PLS_INTEGER,
  MEMBER FUNCTION GetIntervalYM(self IN AnyDataSet,
       inv IN OUT NOCOPY YMINTERVAL_UNCONSTRAINED) return PLS_INTEGER,
  MEMBER FUNCTION GetIntervalDS(self IN AnyDataSet,
       inv IN OUT NOCOPY DSINTERVAL_UNCONSTRAINED) return PLS_INTEGER,
  MEMBER FUNCTION GetNchar(self IN AnyDataSet, nc OUT NOCOPY NCHAR)
       return PLS_INTEGER,
  MEMBER FUNCTION GetNVarchar2(self IN AnyDataSet, nc OUT NOCOPY NVARCHAR2)
       return PLS_INTEGER,
  MEMBER FUNCTION GetNClob(self IN AnyDataSet, nc OUT NOCOPY NCLOB)
       return PLS_INTEGER,
  /***************************************************************************/
  /* NEWLY ADDED FUNCTIONS IN 10iR1 */
  /***************************************************************************/
  /* Set functions for BFloat, BDouble and UROWID. */
  MEMBER PROCEDURE SetBFloat(self IN OUT NOCOPY AnyDataSet, fl IN BINARY_FLOAT,
                    last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetBDouble(self IN OUT NOCOPY AnyDataSet,
                    dbl IN BINARY_DOUBLE, last_elem IN boolean DEFAULT FALSE),
  MEMBER PROCEDURE SetURowid(self IN OUT NOCOPY AnyDataSet, rid IN UROWID,
                    last_elem IN boolean DEFAULT FALSE),
  /* Get functions for Float, Double and UROWID. */
  MEMBER FUNCTION GetBFloat(self IN AnyDataSet, fl OUT NOCOPY BINARY_FLOAT)
       return PLS_INTEGER,
  MEMBER FUNCTION GetBDouble(self IN AnyDataSet, dbl OUT NOCOPY BINARY_DOUBLE)
       return PLS_INTEGER,
  MEMBER FUNCTION GetURowid(self IN AnyDataSet, rid OUT NOCOPY UROWID)
       return PLS_INTEGER
)
/

