create PACKAGE dbms_hs_parallel_metadata  as
  type HvList is table of varchar2(5000);
  type NumList is table of number;
  function check_cap(dblink in varchar2, cap_number in number) return boolean;
  function get_cpu_num return integer;
  function get_domain_name return varchar2;
  procedure  raise_system_error(error_number IN INTEGER, arg1  IN VARCHAR2);
  procedure  loadIndColinfo (remote_schema in varchar2,
  remote_table_name in varchar2, dblink in varchar2,
  ind_available in boolean, max_val in number , min_val in number,
   avg_val in number, part_column in varchar2 , part_col_type in varchar2 ,
   p_col_names in HSBLKNamLst, p_col_types in HSBLKNamLst ,
   col_names in HSBLKNamLst, col_types in HSBLKNamLst,
  parallel_degree in integer);
  procedure  loadHisinfo (remote_schema in varchar2,
  remote_table_name in varchar2, dblink in varchar2,
  ind_available in boolean, numBucket in number , part_column in varchar2 ,
    part_col_type in varchar2 , p_col_names in HSBLKNamLst,
    p_col_types in HSBLKNamLst , hisValues in NumList,
   col_names in HSBLKNamLst, col_types in HSBLKNamLst,
   parallel_degree in integer);
  procedure  loadPatitioninfo (remote_schema in varchar2,
   remote_table_name in varchar2, dblink in varchar2,
   p_cnt in number, p_key_cols in HSBLKNamLst, p_key_cnt in  number,
   typlst in HSBLKNamLst,hvalueList in HvList,
   hvalLen in  NumList, partPos  in NumList ,
   parallel_degree in integer);
  procedure  purgemetadata(remote_schema in varchar2, remote_table_name
  in varchar2, dblink in varchar2 );

  procedure update_samplemeta(remote_schema in varchar2, remote_table_name
  in varchar2, dblink in varchar2 ,parallel_degree in integer,
 sample_column in varchar2, sample_column_type in varchar2);
  procedure load_sampledata(remote_schema in varchar2, remote_table_name
  in varchar2, dblink in varchar2 , low_value in varchar2,
  high_value in varchar2, position in integer);


  procedure  insert_viewobj( ora_view_schema in varchar2, oraview_name
  in varchar2, hsbkseq in number);

  procedure  delete_viewobj( ora_view_schema in varchar2, ora_view_name
  in varchar2);


  procedure table_sampling( remote_schema in varchar2,
      remote_table_name in varchar2, database_link in varchar2,
       hs_remote_tab_typ in varchar2,  p_degree in number,
      row_count in number,  ora_user in varchar2, oracle_table_name  in varchar2,
       pt_col_names in HSBLKNamLst , pt_col_types in  HSBLKNamLst ,
       col_names in  HSBLKNamLst , col_types in  HSBLKNamLst) ;
  procedure schedule_sampling (remote_schema in varchar2,
      remote_table_name in varchar2, database_link in varchar2,
       hs_remote_tab_typ in varchar2, p_degree in integer,
      row_count in number, ora_user in varchar2, oracle_table_name  in varchar2,
      pt_col_names in HSBLKNamLst , pt_col_types in  HSBLKNamLst ,
      col_names in  HSBLKNamLst , col_types in  HSBLKNamLst);


end dbms_hs_parallel_metadata;
/

