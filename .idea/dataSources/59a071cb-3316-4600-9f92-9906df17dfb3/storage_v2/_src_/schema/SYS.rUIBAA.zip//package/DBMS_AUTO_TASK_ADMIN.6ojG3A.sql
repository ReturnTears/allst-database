create PACKAGE dbms_auto_task_admin AS
-- PUBLIC CONSTANTS
--
-- Option Flags
--
OPTFLG_DEFERRED  CONSTANT VARCHAR2(16) := 'DEFERRED';
OPTFLG_IMMEDIATE CONSTANT VARCHAR2(16) := 'IMMEDIATE';

--
-- Task Priority
--
PRIORITY_MEDIUM CONSTANT  VARCHAR2(6) := 'MEDIUM';
       -- Task with this priority should be executed as time permits.
PRIORITY_HIGH   CONSTANT  VARCHAR2(6) := 'HIGH';
       -- Task with this priority should be executed within
       -- the current Maintenance Window.
PRIORITY_URGENT CONSTANT  VARCHAR2(6) := 'URGENT';
       -- Task with this is to be executed at the earliest opportunity.
PRIORITY_CLEAR  CONSTANT  VARCHAR2(6) := 'CLEAR';
       -- This isepcial priority is used to clear previous settings
--
-- Settable Attrributes
--
-- The following two attributes are mutually exclusive
-- Setting either one will automatically unset the other
LIGHTWEIGHT          CONSTANT VARCHAR2(16) := 'LIGHTWEIGHT';
HEAVYWEIGHT          CONSTANT VARCHAR2(16) := 'HEAVYWEIGHT';

-- The following two attributes are mutually exclusive
-- Setting either one will automatically unset the other
VOLATILE             CONSTANT VARCHAR2(16) := 'VOLATILE';
STABLE               CONSTANT VARCHAR2(16) := 'STABLE';

-- The following two attributes are mutually exclusive
-- Setting either one will automatically unset the other
SAFE_TO_KILL         CONSTANT VARCHAR2(16) := 'SAFE_TO_KILL';
DO_NOT_KILL          CONSTANT VARCHAR2(16) := 'DO_NOT_KILL';

--
-- Attribute value flags
--
ATTRVAL_TRUE     CONSTANT VARCHAR2(5)  := 'TRUE';
ATTRVAL_FALSE    CONSTANT VARCHAR2(5)  := 'FALSE';

-- GET_P1_RESOURCES
--
-- This procedure returns percent of resources allocated to each
-- AUTOTASK High Priority Consumer Group.
--
-- Values will add up to 100 (percent).
PROCEDURE GET_P1_RESOURCES (
  STATS_GROUP_PCT   OUT      NUMBER,  -- %resources for Statistics Gathering
  SEG_GROUP_PCT     OUT      NUMBER,  -- %resources for Space Management
  TUNE_GROUP_PCT    OUT      NUMBER,  -- %resources for SQL Tuning
  HEALTH_GROUP_PCT  OUT      NUMBER   -- %resources for Health Checks
);

-- SET_P1_RESOURCES
--
-- This procedure sets percentage-based resource allocation for each
-- High Priority Consumer Group used by AUTOTASK Clients.
--
-- Values must be integers in the range 0 to 100, and must add up to 100
-- (percent), otherwise, an exception is raised.
--
PROCEDURE SET_P1_RESOURCES (
  STATS_GROUP_PCT    IN      NUMBER, -- %resources for Statistics Gathering
  SEG_GROUP_PCT      IN      NUMBER, -- %resources for Space Management
  TUNE_GROUP_PCT     IN      NUMBER, -- %resources for SQL Tuning
  HEALTH_GROUP_PCT   IN      NUMBER  -- %resources for Health Checks
);

-- SET_CLIENT_SERVICE API
--
-- This procedure associates an AUTOTASK Client with a specified Service.
-- All work performed on behalf of the Client will take place only on
-- instances where the service is enabled.
--
PROCEDURE SET_CLIENT_SERVICE (
  CLIENT_NAME      IN      VARCHAR2,  -- name of the client, as found in
                                      -- DBA_AUTOTASK_CLIENT View.
  SERVICE_NAME     IN      VARCHAR2   -- Service name for client, may be NULL
);

--GET_CLIENT_ATTRIBUTES API
--
-- This procedure returns values of select client attributes.
--
PROCEDURE GET_CLIENT_ATTRIBUTES (
  CLIENT_NAME      IN      VARCHAR2, -- name of the client, as found in
                                     -- DBA_AUTOTASK_CLIENT View.
  SERVICE_NAME    OUT      VARCHAR2, -- Service name for client, may be NULL
  WINDOW_GROUP    OUT      VARCHAR2  -- Name of the window group in which
                                     -- the client is active
);

--
-- DISABLE API
-- This interface prevents Autotask from executing any requests
--

-- Disabling AUTOTASK
--
-- This version completely disables all AUTOTASK functionality.
-- If "IMMEDIATE" is specified, all running AUTOTASK jobs will be stopped.
--
PROCEDURE DISABLE;


-- Disabling an AUTOTASK Client
--  (optionally, only affecting one maintenance window)
--  (optionally, disabling a specific Operation for a Client)
--
-- This version disables specified a client.
-- Either a specific operation or a maintenance window name, but
-- not both, are meaningful.
-- If an operation is disabled, tasks specifying this operation
--  will not be performed. WINDOW_NAME is ignored for OPERATION.
--
-- If a window name is specified, client will be disabled in the
-- specified window.
--
PROCEDURE DISABLE (
  CLIENT_NAME        IN    VARCHAR2,  -- name of the client, as found in
                                      -- DBA_AUTOTASK_CLIENT View.
  OPERATION          IN    VARCHAR2,  -- Name of the operation as specified in
                                      -- DBA_AUTOTASK_OPERATION View
  WINDOW_NAME        IN    VARCHAR2   -- optional name of the window in which
                                      -- client is to be disabled
);

-- ENABLE API
--
-- This interface allows a previously disabled client, operation,
--

-- Re-Enabling AUTOTASK
PROCEDURE ENABLE;

--
-- Re-Enabling a Client
-- Optionally, re-enabling an Operation
-- Optionally, re-enabling a Client in a specific maintenance window
--
-- Either a specific operation or a maintenance window name, but
-- not both, may be specified.
--
PROCEDURE ENABLE (
  CLIENT_NAME      IN      VARCHAR2,  -- name of the client, as found in
                                      -- DBA_AUTOTASK_CLIENT View.
  OPERATION        IN      VARCHAR2,  -- Name of the operation as specified in
                                      -- DBA_AUTOTASK_OPERATION View
  WINDOW_NAME      IN      VARCHAR2    -- optional name of the window in
                                       -- which the client is to be enabled.
);


-- OVERRIDE_PRIORITY API
--
-- This API is used to manually override task priority. This can be done
-- at the client, operation or individual task level. This priority assignment
-- will be honored during the next maintenance window in which the named
-- client is active. Specifically, setting the priority to Urgent will cause
-- a high priority job to be generated at the start of the maintenance window.
--
-- The following priorities are defined:
-- PRIORITY_MEDIUM - 'time permitting'
-- PRIORITY_HIGH   - normal priority
-- PRIORITY_URGENT - 'ASAP'
--
-- Setting PRIORITY to PRIORITY_CLEAR removes the override.
--

-- Override Priority for a Client
PROCEDURE OVERRIDE_PRIORITY (
  CLIENT_NAME     IN      VARCHAR2, -- name of the client as found in
                                    -- DBA_AUTOTASK_CLIENT View.
  PRIORITY        IN      VARCHAR2  -- See above.
);

-- Override Priority for an Operation
PROCEDURE OVERRIDE_PRIORITY (
  CLIENT_NAME  IN      VARCHAR2, -- name of the client as found in
                                 -- DBA_AUTOTASK_CLIENT View.
  OPERATION    IN      VARCHAR2, -- Name of the operation as specified in
                                 -- DBA_AUTOTASK_OPERATION View
  PRIORITY     IN      VARCHAR2  -- See above
);


-- SET_ATTRIBUTE API
--
-- This API is used to set boolean attributes for a Client, Operation, or Task.
-- The following attributes may be set:
--   LIGHTWEIGHT
--   HEAVYWEIGHT
--             - seting either of the above attributes ON, turns the other OFF
--   VOLATILE
--   STABLE
--             - seting either of the above attributes ON, turns the other OFF
--   SAFE_TO_KILL
--   DO_NOT_KILL
--             - seting either of the above attributes ON, turns the other OFF
--
-- Setting attributes for a Client
PROCEDURE SET_ATTRIBUTE (
  CLIENT_NAME        IN      VARCHAR2, -- Name of the client as found in
                                       -- DBA_AUTOTASK_CLIENT View.
  ATTRIBUTE_NAME     IN      VARCHAR2, -- Attribute to be set
  ATTRIBUTE_VALUE    IN      VARCHAR2  -- Attribute value, "TRUE", "FALSE"
);

-- Setting attributes for an Operation
PROCEDURE SET_ATTRIBUTE (
  CLIENT_NAME        IN      VARCHAR2, -- Name of the client as found in
                                       -- DBA_AUTOTASK_CLIENT View.
  OPERATION          IN      VARCHAR2, -- Name of the operation as in
                                       -- DBA_AUTOTASK_OPERATION View
  ATTRIBUTE_NAME     IN      VARCHAR2, -- Attribute to be set
  ATTRIBUTE_VALUE    IN      VARCHAR2  -- Attribute value, "TRUE", "FALSE"
);

end dbms_auto_task_admin;
/

