create PACKAGE dbms_defer AS
  -------------------
  --  OVERVIEW
  --
  -- This package is the user interface to a replicated transactional
  -- deferred remote
  -- procedure call facility.  Replicated applications use the calls
  -- in this interface
  -- to queue procedure call for later transactional execution at remote nodes.
  -- These routines are typically called from either after row triggers
  -- or application
  -- specified update procedures.
  ------------
  --  SECURITY
  --
  -- This package is not granted to public because a user can
  -- potentially steal the rights of the user pushing the deferred rpcs.
  -- Be careful when granting execute privileges on dbms_defer.
  -------------
  --  CONSTANTS
  --
  --    The following constants are deprecated, please
  --    use the corresponding one defined in DBMS_DEFER_QUERY.
  --
  arg_type_num       CONSTANT NUMBER := dbms_defer_query.arg_type_num;
  arg_type_char      CONSTANT NUMBER := dbms_defer_query.arg_type_char;
  arg_type_varchar2  CONSTANT NUMBER := dbms_defer_query.arg_type_varchar2;
  arg_type_date      CONSTANT NUMBER := dbms_defer_query.arg_type_date;
  arg_type_rowid     CONSTANT NUMBER := dbms_defer_query.arg_type_rowid;
  arg_type_raw       CONSTANT NUMBER := dbms_defer_query.arg_type_raw;
  arg_type_blob      CONSTANT NUMBER := dbms_defer_query.arg_type_blob;
  arg_type_clob      CONSTANT NUMBER := dbms_defer_query.arg_type_clob;
  arg_type_bfil      CONSTANT NUMBER := dbms_defer_query.arg_type_bfil;
  arg_type_cfil      CONSTANT NUMBER := dbms_defer_query.arg_type_cfil;
  arg_type_time      CONSTANT NUMBER := dbms_defer_query.arg_type_time;
  arg_type_ttz       CONSTANT NUMBER := dbms_defer_query.arg_type_ttz;
  arg_type_timestamp CONSTANT NUMBER := dbms_defer_query.arg_type_timestamp;
  arg_type_tstz      CONSTANT NUMBER := dbms_defer_query.arg_type_tstz;
  arg_type_iym       CONSTANT NUMBER := dbms_defer_query.arg_type_iym;
  arg_type_ids       CONSTANT NUMBER := dbms_defer_query.arg_type_ids;
  arg_type_tsltz     CONSTANT NUMBER := dbms_defer_query.arg_type_tsltz;
  -----------
  --    The following constants are deprecated, please
  --    use the corresponding one defined in DBMS_DEFER_QUERY.
  arg_csetid_none       CONSTANT NUMBER := dbms_defer_query.arg_csetid_none;
  arg_form_none         CONSTANT NUMBER := dbms_defer_query.arg_form_none;
  arg_form_implicit     CONSTANT NUMBER := dbms_defer_query.arg_form_implicit;
  arg_form_nchar        CONSTANT NUMBER := dbms_defer_query.arg_form_nchar;
  arg_form_any          CONSTANT NUMBER := dbms_defer_query.arg_form_any;
  --     definition same as dbms_repcat_mas.repcat_status_normal
  --     (don't want to require repcat to be loaded)
  repcat_status_normal  CONSTANT NUMBER := 0.0;
  --
  ---------
  --  TYPES
  --
  --    node list type used for the defer_txn call
  --      representation is an array (table) indexed from 1 up to a NULL
  --      entry or NO_DATA_FOUND
  TYPE node_list_t IS TABLE OF  VARCHAR2(128) INDEX BY BINARY_INTEGER;
  --
  -----------------
  --  EXCEPTIONS
  --
  --  Parameter type does not match actual type.
  bad_param_type EXCEPTION;
  PRAGMA exception_init(bad_param_type, -23325);
  bad_param_num NUMBER := -23325;

  --  The database is being quiesced.
  deferred_rpc_quiesce EXCEPTION;
  PRAGMA exception_init(deferred_rpc_quiesce, -23326);
  quiesce_num NUMBER := -23326;
  quiesce_msg VARCHAR(76) := 'the system is being quiesced.';

  --  Generic errors that are not important enough for specific exceptions
  --  string text will explain them further.  These are internal errors.
  --  message varies.
  dbms_defererror EXCEPTION;
  PRAGMA exception_init(dbms_defererror, -23305);
  deferror_num NUMBER := -23305;

  --
  --    dbms_defer package detects mal-formed call (e.g. argument count
  --     miss-match).  Message varies.
  malformedcall EXCEPTION;
  PRAGMA  exception_init(malformedcall, -23304);
  malformed_num NUMBER := -23304;

  --   generic exceptions that (user-written) deferred procedures
  --   can raise to indicate
  --   that the remote update has failed because of data updates by concurrent
  --   transactions.  A deferror table record will be created by the deferred
  --    rpc executor
  updateconflict  EXCEPTION;
  PRAGMA  exception_init(updateconflict, -23303);
  conflict_num NUMBER := -23303;
  conflict_msg VARCHAR(76) := 'Remote update failed due to conflict.';

  --   generic exceptions that (user-written) deferred procedures
  --   can raise to indicate
  --   that the remote update has failed because communications failures
  --   so that a a deferror table record will not be created by the
  --   deferred rpc
  --   executor.

  condescfailure  EXCEPTION; -- connection description for remote db not found
  PRAGMA  exception_init(condescfailure, -2019);
  condescfail_num NUMBER := -2019;

  commfailure  EXCEPTION;
  PRAGMA  exception_init(commfailure, -23302);
  commfail_num NUMBER := -23302;
  commfail_msg VARCHAR(76) :=
                         'Remote update failed due to communication failure';

  noparalprop  EXCEPTION;
  PRAGMA  exception_init(noparalprop, -26575);
  noparalprop_num NUMBER := -26575;

  --   mixed use repcat determined destinations and non-repcat destinations
  --   in one transaction
  mixeddest  EXCEPTION;
  PRAGMA  exception_init(mixeddest, -23301);
  mixeddest_num NUMBER := -23301;
  mixeddest_msg VARCHAR(76) :=
           'Destinations for transaction not consistently specified';

  --   parameter length exceed deferred rpc limits (2000 char/varchar2,
  --   255 raw) in one transaction
  parameterlength  EXCEPTION;
  PRAGMA  exception_init(parameterlength, -23323);
  paramlen_num NUMBER := -23323;
  paramlen_msg VARCHAR(76) := 'parameter length exceeds deferred rpc limits';

  --   deferred rpc execution is disabled
  executiondisabled  EXCEPTION;
  PRAGMA  exception_init(executiondisabled, -23354);
  executiondisabled_num NUMBER := -23354;
  paramlen_msg VARCHAR(76) := 'parameter length exceeds deferred rpc limits';

  --   deferred rpc processing is disabled
  rpcdisabled  EXCEPTION;
  PRAGMA  exception_init(rpcdisabled, -23473);
  rpcdisabled_num NUMBER := -23473;
  ----------------------
  --  PROCEDURES
  --
  PROCEDURE commit_work(commit_work_comment IN VARCHAR2);
  --  Perform a transaction commit after checking for well-formed
  --    deferred RPCs.
  --    Must be used instead of the commit work sql call for
  --    transactions deferring RPCS.
  --    Updates the comment_comment and commit_scn fields in
  --    the def$_txn table.
  --  Input parameters:
  --    commit_work_comment
  --      Up to fifty characters to describe the transaction
  --        in the def$_txns
  --        table and system two-phase commit tables (this latter
  --        once we figure out
  --        how to get it in.)  Comment is truncated to fifty characters.
  --  Exceptions
  --    ORA-23304 (malformedcall) if there is an defer_rpc_arg
  --      call missing or defer_txn
  --      was not called for this transaction.
  --
  --
  --
  --  Transaction and call deferral procedures
  --    A deferred transaction consist of the following:
  --      Call to dbms_defer.transaction (this is optional, the first call to
  --      dbms_defer.call will call transaction)
  --      one or more complete calls, each of which consists of
  --        Call to dbms_defer.call
  --           zero of more calls (depending on arg_count in
  --           dbms_defer.call) to dbms_defer.arg_*
  --      commit or call to commit_work
  --
  --  DESTINATION SPECIFICATION
  --  Destinations can be specified in several ways
  --  A) All deferred procedures are in repcat and the default list is
  --     NOT specified in the transaction call.
  --  OR
  --  B) destinations are specified without repcat using the following order
  --     of precedence
  --   1) list specified in the nodes parameter to dbms_defer.call
  --   2) list specified in the nodes parameter to dbms_defer.transaction
  --   3) list specified in defdefaultdest table.
  --   The mixeddest exception is raised if an attempt to mix destinations
  --   modes is detected.
  --
  PROCEDURE transaction;
  PROCEDURE transaction(nodes      IN node_list_t);
  --  Mark a transaction as deferred (as containing deferred RPCs )
  --     This call is optional.  The first call to dbms_defer.call
  --     in a transaction will call
  --     deftxn (with no arguments) if it has not been previously called.
  --     Input parameters are optional, and if they are not
  --     specified the destination
  --     list is taken from the system defaults stored in the
  --     def$_defaultdest table and
  --     maintained by the dbms_defer_sys.add_default_node and
  --     dbms_defer_sys.delete_default_node calls
  --  Input parameters:
  --    nodes
  --      Table containing a list of nodes (dblink) to propagate the
  --      deferred calls of the
  --        transaction to.  Indexed from 1 until a NULL entry is
  --        found or NO_DATA_FOUND is raised.
  --        Case insensitive comparison
  --        used for node lists.
  --        Use of this parameter overrides distribution lists as
  --        specified in repcat.
  --  Exceptions
  --    ORA-23304 (malformedcall) if the previous transaction
  --      not correctly formed
  --      or terminated
  --    ORA-23319 Parameter value is not appropriate
  --    ORA-23352 Raised by dbms_defer.call if the node
  --              list contains duplicates
  ----

  PROCEDURE call( schema_name  IN VARCHAR2,
                  package_name IN VARCHAR2,
                  proc_name    IN VARCHAR2,
                  arg_count    IN NATURAL,
                  group_name   IN VARCHAR2 := '');

  PROCEDURE call( schema_name  IN VARCHAR2,
                  package_name IN VARCHAR2,
                  proc_name    IN VARCHAR2,
                  arg_count    IN NATURAL,
                  nodes        IN node_list_t);
  --  Defer a remote procedure call.  Automatically call
  --    deftxn if this is the first
  --    call call of a transaction.
  --  Input parameters:
  --    schema_name
  --      Name of the schema containing the remote procedure.  For
  --      compatibility with future compile-time checking only string
  --      constants should be used.
  --    package_name
  --      Name of the package containing the remote procedure.  For
  --      compatibility with future compile-time checking only string
  --      constants should be used.
  --    proc_name
  --      Name of the remote procedure to call.
  --        For compatibility with
  --        future syntactic integration
  --        and compile-time checking only string constants should be used.
  --    arg_count
  --       Number of parameters to the procedure.  This must
  --       exactly match the number of
  --       defrpcarg_* calls immediately following the dbms_defer.call call.
  --    group_name
  --       Reserved for internal use
  --    nodes
  --      Optional table containing a list of nodes to propagate the
  --      deferred call to.
  --        Indexed from 1 until a NULL entry is
  --        found or NO_DATA_FOUND is raised.
  --        Case insensitive comparison
  --        used for node lists.
  --      If not specified, the destination list is determined by the
  --      list passed to the transaction procedure, or the system defaults,
  --      Use of this parameter in any deferred call invalidate the use of
  --      the use of repcat to determine distribution lists in any
  --      calls for a transaction.
  --  Exceptions  --
  --  Exceptions
  --    ORA-23304 (malformedcall) if the previous call not
  --      correctly formed (number of
  --      defrpcarg_* call not matched to arg_count).
  --    ORA-23319 Parameter value is not appropriate
  --    ORA-23352  If the destination list (specified by nodes or by a previous
  --              dbms_defer.transaction call contains a duplicate.
  ----

  PROCEDURE number_arg(arg IN nUMBER);
  --  Queue a number parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The number value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE date_arg(arg IN DATE);
  --  Queue a date parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The date value of the parameter to the call previously
  --      deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE varchar2_arg(arg  IN VARCHAR2);
  --  Queue a varchar2 parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The varchar2 value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  PROCEDURE nvarchar2_arg(arg IN NVARCHAR2);
  --  Queue an nvarchar2 parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The nvarchar2 value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  PROCEDURE any_varchar2_arg(arg  IN VARCHAR2 CHARACTER SET ANY_CS);
  --  Queue a varchar2 parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The varchar2 value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  PROCEDURE char_arg(arg  IN CHAR);
  --  Queue a char parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The char value of the parameter to the call previously
  --        deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  PROCEDURE nchar_arg(arg IN NCHAR);
  --  Queue an nchar parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The nchar value of the parameter to the call previously
  --        deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  PROCEDURE any_char_arg(arg  IN CHAR CHARACTER SET ANY_CS);
  --  Queue a char parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The char value of the parameter to the call previously
  --        deferred with a
  --        dbms_defer.call call. The length of arg is limited to 2000.
  --  Exceptions:
  --    whatever error sql gives if arg exceeds 2000 characters.

  ---------------------
  -- rowids can not be
  -- used on different nodes.  It might be reasonable to use a
  -- rid in a deferred call
  -- to a local node, but be careful.
  PROCEDURE rowid_arg(arg IN ROWID);
  --  Queue a rowid parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The rowid value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions:
  --    dbms_deferError
  --------

  -- The following calls will not be supported until dbms_sql
  -- supports
  --
  PROCEDURE raw_arg(arg IN raw);
  --  Queue a rowid parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The raw value of the parameter to the call
  --        previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions:
  --    dbms_deferError
  --------

  PROCEDURE blob_arg(arg IN BLOB);
  --  Queue a BLOB for a deferred call.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

  PROCEDURE clob_arg(arg IN CLOB);
  --  Queue a CLOB for a deferred call.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

  PROCEDURE any_clob_arg(arg IN CLOB CHARACTER SET ANY_CS);
  --  Queue a CLOB for a deferred call.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

  PROCEDURE nclob_arg(arg IN NCLOB);
  --  Queue an NCLOB for a deferred call.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

  PROCEDURE time_arg(arg IN TIME_UNCONSTRAINED);
  --  Queue a time parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The time value of the parameter to the call previously
  --      deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE timestamp_arg(arg IN TIMESTAMP_UNCONSTRAINED);
  --  Queue a timestamp parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The timestamp value of the parameter to the call previously
  --      deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE ttz_arg(arg IN TIME_TZ_UNCONSTRAINED);
  --  Queue a time with time zone parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The time with time zone value of the parameter to the call previously
  --      deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE tstz_arg(arg IN TIMESTAMP_TZ_UNCONSTRAINED);
  --  Queue a timestamp with time zone parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The timestamp with time zone value of the parameter to the call
  --      previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE tsltz_arg(arg IN TIMESTAMP_LTZ_UNCONSTRAINED);
  --  Queue a timestamp with local timezone parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The timestamp with local time zone value of the parameter to the call
  --      previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE iym_arg(arg IN YMINTERVAL_UNCONSTRAINED);
  --  Queue a interval year to month parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The interval year to month value of the parameter to the call
  --      previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

  PROCEDURE ids_arg(arg IN DSINTERVAL_UNCONSTRAINED);
  --  Queue a interval date to second parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The interval date to second value of the parameter to the call
  --      previously deferred with a
  --        dbms_defer.call call.
  --  Exceptions: none.
  --------

--  PROCEDURE bfile_arg(arg IN BFILE);
  --  Queue the contents of a binary file for a deferred call.  The contents
  --    are interpreted and stored as a BLOB.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

--  PROCEDURE cfile_arg(arg IN CFILE);
  --  Queue the contents of a binary file for a deferred call.  The contents
  --    are interpreted and stored as a CLOB.
  --  Input parameter:
  --    arg
  --      The value of the parameter to the call previously
  --        deferred with a dbms_defer.call call.
  --------

  PROCEDURE anydata_arg(arg IN Sys.AnyData);
  --  Queue a anydata for the parameter value for a deferred call.
  --  Input parameter:
  --    arg
  --      The user data
  --      previously deferred with a dbms_defer.call call.
  --      The supported types are Collections and Object types.
  --      It does not support REF types, Opaque types, AnyData, AnyType and
  --      AnyDataSet.
  --------

  --
  -- Public procs for parallel prop txn log records
  --

  PROCEDURE record_transaction(origin_site_p        IN VARCHAR2,
                               origin_dblink_p      IN VARCHAR2,
                               transaction_number_p IN NUMBER);
  -- Record transaction in def$_origin as current connected user
  --
  -- Inputs:
  --    origin_site_p
  --      fully qualified global name of the pushing site
  --    origin_dblink_p
  --      dblink used by the pushing site (may have a qualifier)
  --    transaction_number_p
  --      trans seq number to record
  --------
  --------

  PROCEDURE purge_transaction_log(origin_site_p        IN VARCHAR2,
                                  origin_dblink_p      IN VARCHAR2,
                                  transaction_number_p IN NUMBER);
  -- Purge from def$_origin all txns with given parameters and current
  --   connected user id
  -- Inputs:
  --   origin_site_p
  --      fully qualified global name of the pushing site
  --    origin_dblink_p
  --      dblink used by the pushing site (may have a qualifier)
  --    transaction_number_p
  --      least transaction seq number to retain
  --------
  --------

  --
  -- Public procs for parallel prop recovery set retrieval
  --

  PROCEDURE get_txn_log_runs(
      origin_site IN VARCHAR2,
      origin_dblink IN VARCHAR2,
      in_tran_seq IN NUMBER);
  --  Initialize for retrieving run-encoded set of txn sequence numbers
  --    from destination site
  --  Input parameters:
  --    origin_site
  --      fully qualified global name of the pushing site
  --    origin_dblink
  --      dblink used by the pushing site (may have a qualifier)
  --    in_tran_seq
  --      initial trans seq number to return (all earlier seqs
  --      are known by pushing site already)
  --
  --   It's obsolete in 8.2[+].
  --------
  --------

  PROCEDURE get_next_txn_log_run(
      run_seq       OUT NUMBER,
      run_len       OUT NUMBER,
      scn_first     OUT NUMBER,
      id_first      OUT VARCHAR2,
      scn_last      OUT NUMBER,
      id_last       OUT VARCHAR2);
  --  Retrieve next run of applied txn sequence numbers
  --    as specified by prior call to get_txn_log_runs
  --  Runs are returned in increasing order by seq
  --    which is also increasing order by commit number
  --    (i.e. <scn, id>)
  -- Outputs:
  --   run_seq, run_len
  --     returned run bounds; an empty (0-length) run indicates
  --     end-of-data
  --   scn_first, id_first
  --     commit number of first txn in run
  --   scn_last, id_last
  --     commit number of last txn in run
  --
  --   It's obsolete in 8.2[+].
  --------
  --------

END dbms_defer;
/

