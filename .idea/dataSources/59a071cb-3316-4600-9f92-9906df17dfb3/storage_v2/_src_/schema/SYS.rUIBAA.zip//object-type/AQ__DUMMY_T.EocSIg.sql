create TYPE     aq$_dummy_t AS OBJECT (data CHAR(1));
/

