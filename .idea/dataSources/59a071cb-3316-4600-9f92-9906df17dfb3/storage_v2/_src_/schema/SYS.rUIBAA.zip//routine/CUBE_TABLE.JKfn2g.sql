create function CUBE_TABLE wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
7f a2
QzUf5JyTzy3etZxTULoHHpFaVQgwg0wYf8upynSmkELpgEx2cZCew3msAmd/OJu1nXxgho9i
nHFIJgaJjKkKp9zp/U14pcB4zmqbzt2K30frpc1YoMk3JZfjJXrFbwkL00meVl1rb6eU4N3b
Ep6w/1VExmt2zw==
/

