create type AWRDRPT_TEXT_TYPE
  as object (output varchar2(320 CHAR))
/

