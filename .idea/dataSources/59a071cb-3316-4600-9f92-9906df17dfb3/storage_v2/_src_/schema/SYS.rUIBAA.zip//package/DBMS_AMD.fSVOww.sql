create package dbms_amd as

-- Move olap catalog to new tablespace
  procedure Move_OLAP_Catalog(dest_tbs IN varchar2);

end dbms_amd;
/

