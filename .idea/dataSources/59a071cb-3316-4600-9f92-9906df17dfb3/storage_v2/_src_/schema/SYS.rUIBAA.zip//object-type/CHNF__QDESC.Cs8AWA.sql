create type chnf$_qdesc as object(
    queryid number,
    queryop number,
    table_desc_array chnf$_tdesc_array)
/

