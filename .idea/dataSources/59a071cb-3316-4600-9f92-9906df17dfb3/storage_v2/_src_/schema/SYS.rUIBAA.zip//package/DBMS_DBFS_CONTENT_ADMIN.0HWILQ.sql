create package dbms_dbfs_content_admin
    authid definer
as



    /*
     * Administrative and query APIs:
     *
     * (Administrative) clients and store providers are expected to
     * register stores with the DBFS API. Additionally, administrative
     * clients are expected to mount stores into the toplevel namespace
     * of their choice.
     *
     * The registration/unregistration of a store is separated from the
     * mount/unmount of a store since it is possible for the same store
     * to be mounted multiple times at different mount-points (and this
     * is under client control).
     *
     *
     * The administrative methods in "dbms_dbfs_content" are merely
     * wrappers that delegate to the matching methods in
     * "dbms_dbfs_content_admin". Clients can use the methods in either
     * package to perform administrative operations.
     *
     */



    /*
     * Register a new store "store_name" backed by provider
     * "provider_name" that uses "provider_package" as the store
     * provider (conforming to the "dbms_dbfs_content_spi" package
     * signature).
     *
     * This method is to be used primarily by store providers after they
     * have created a new store.
     *
     * Store names must be unique.
     *
     */

    procedure   registerStore(
        store_name          in      varchar2,
        provider_name       in      varchar2,
        provider_package    in      varchar2);


    /*
     * Unregister a previously registered store (invalidating all
     * mount-points associated with it).
     *
     * Once unregistered all access to the store (and its mount-points)
     * are not guaranteed to work (although CR may provide a temporary
     * illusion of continued access).
     *
     *
     * If the "ignore_unknown" argument is "true", attempts to
     * unregister unknown stores will not raise an exception.
     *
     */

    procedure   unregisterStore(
        store_name          in      varchar2,
        ignore_unknown      in      boolean         default false);


    /*
     * Mount a registered store "store_name" and bind it to the
     * "store_mount" mount-point.
     *
     * Once mounted, accesses to pathnames of the form
     * "/<store_mount>/xyz..." will be redirected to <store_name> and
     * its store provider.
     *
     *
     * Store mount-points must be unique, and a syntactically valid
     * pathname component (i.e. a "name_t" with no embedded "/").
     *
     *
     * If a mount-point is not specified (i.e. is null), the DBFS API
     * attempts to use the store name itself as the mount-point name
     * (subject to the uniqueness and syntactic constraints).
     *
     *
     * A special empty mount-point is available for single stores, i.e.
     * a scenario where the DBFS API manages a single backend store---in
     * such cases, the client can directly deal with full pathnames of
     * the form "/xyz..." since there is no ambiguity in how to redirect
     * these accesses.
     *
     * Singleton mount-points are indicated by the "singleton" boolean
     * argument, and the "store_mount" argument is ignored.
     *
     *
     * The same store can be mounted multiple times, obviously at
     * different mount-points.
     *
     *
     * Mount properties can be used to specify the DBFS API execution
     * environment, i.e. default values of the principal, owner, acl,
     * and asof for a particular mount-point. Mount properties can also
     * be used to specify a read-only store.
     *
     */

    procedure   mountStore(
        store_name          in      varchar2,
        store_mount         in      varchar2        default null,
        singleton           in      boolean         default false,
        principal           in      varchar2        default null,
        owner               in      varchar2        default null,
        acl                 in      varchar2        default null,
        asof                in      timestamp       default null,
        read_only           in      boolean         default false);


    /*
     * Unmount a previously mounted store, either by name or by mount
     * point.
     *
     * Single stores can be unmounted only by store name (since they
     * have no mount-points).
     *
     * Attempting to unmount a store by name will unmount all
     * mount-points associated with the store.
     *
     * Once unmounted all access to the store (or mount-point) are not
     * guaranteed to work (although CR may provide a temporary illusion
     * of continued access).
     *
     *
     * If the "ignore_unknown" argument is "true", attempts to
     * unregister unknown stores/mounts will not raise an exception.
     *
     */

    procedure   unmountStore(
        store_name          in      varchar2        default null,
        store_mount         in      varchar2        default null,
        ignore_unknown      in      boolean         default false);


    /*
     * Update operation statistics for a store/mount.
     *
     * Statistics flushes are invoked by the DBFS API operations, and
     * update the common metadata tables in a secure manner.
     *
     */

    procedure   updateStats(
        store_name          in      varchar2,
        store_mount         in      varchar2,
        op                  in      integer,
        cnt                 in      integer,
        wt                  in      integer,
        ct                  in      integer);



    /*
     * Utility function: check SPI.
     *
     *
     * Given the name of a putative "dbms_dbfs_content_spi" conforming
     * package, attempt to check that the package really does implement
     * all of the provider methods (with the proper signatures), and
     * report on the conformance.
     *
     * The result is generated into the "chk" lob that the caller must
     * manage.
     *
     * This is a helper for "dbms_dbfs_content.checkSpi()".
     *
     */

    procedure   checkSpi(
        schema_name         in              varchar2,
        package_name        in              varchar2,
        chk                 in out nocopy   clob);



    /*
     * Utility function: update DBFS context.
     *
     * Internal helper function that modifies the DBFS context (and
     * allows sessions to refresh their internal state on subsequent
     * operations). Invoked by various clients after any significant
     * changes to persistent state.
     *
     */

    procedure   updateCtx;
end;
/

